from django.contrib import admin


from filmlist.models import Movies
admin.site.register(Movies)
